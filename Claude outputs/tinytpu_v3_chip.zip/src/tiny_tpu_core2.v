/*
 * Copyright (c) 2026 MAC Attack (Alex Salamati, James Manikyan, Marco Flores)
 * SPDX-License-Identifier: Apache-2.0
 *
 * tiny_tpu_core2: Tiny-TPU v3 core. Two signed INT8 processing elements side by side (a 1x2 array)
 * sharing one input buffer. Both PEs read the same stored input x[ptr] each clock and multiply it by
 * their own weight, so they compute two neurons of a layer at once (2 MACs per clock).
 * Platform-independent: the Tiny Tapeout and FPGA tops only add pins / a bus around it.
 *
 * Commands (valid = 1; din is the data byte):
 *   0 NOP
 *   1 CLEAR   acc0 = acc1 = 0, both overflow flags = 0, ptr = 0
 *   2 LOAD_X  x[ptr] <= din, ptr++                     store the layer's inputs (up to N)
 *   3 MAC     acc0 += x[ptr] * din, ptr++              one weight, PE 0 only (single-PE use)
 *   4 READ    result0 <= acc0, result1 <= acc1
 *   5-7       NOP here (the Tiny Tapeout top uses 5 for its BURST command)
 * Dual MAC (mac2 = 1, takes priority over a command in the same clock):
 *             acc0 += x[ptr] * w0, acc1 += x[ptr] * w1, ptr++
 *
 * Numbers as in v2: signed INT8 inputs and weights, exact 22-bit sums (up to 127 worst-case products
 * per neuron; a neuron has at most N = 32 inputs), a sticky overflow flag per PE until CLEAR.
 * ptr counts modulo N, so a neuron must not have more than N inputs.
 */

`default_nettype none

module tiny_tpu_core2 #(
    parameter N   = 32,     // input buffer depth; keep 32 (ptr_out and the status byte use a 5-bit position)
    parameter ACC = 22
) (
    input  wire                  clk,
    input  wire                  rst,          // synchronous, active high
    input  wire                  valid,
    input  wire        [2:0]     cmd,
    input  wire        [7:0]     din,
    input  wire                  mac2,         // dual MAC this clock
    input  wire        [7:0]     w0,
    input  wire        [7:0]     w1,
    output reg  signed [ACC-1:0] result0,
    output reg  signed [ACC-1:0] result1,
    output reg                   ovf0,
    output reg                   ovf1,
    output wire        [4:0]     ptr_out
);

  localparam PW = (N <= 2) ? 1 : $clog2(N);
  localparam [2:0] C_CLEAR = 3'd1, C_LOAD = 3'd2, C_MAC = 3'd3, C_READ = 3'd4;

  reg signed [7:0]     x [0:N-1];
  reg        [PW-1:0]  ptr;
  reg signed [ACC-1:0] acc0, acc1;

  wire signed [7:0]   xi = x[ptr];
  // PE 0 takes w0 in a dual MAC and din in a single MAC
  wire signed [7:0]   wa = mac2 ? w0 : din;
  wire signed [15:0]  p0 = xi * wa;
  wire signed [15:0]  p1 = xi * $signed(w1);
  wire signed [ACC:0] s0 = {acc0[ACC-1], acc0} + {{(ACC-15){p0[15]}}, p0};
  wire signed [ACC:0] s1 = {acc1[ACC-1], acc1} + {{(ACC-15){p1[15]}}, p1};

  always @(posedge clk) begin
    if (rst) begin
      acc0    <= {ACC{1'b0}};
      acc1    <= {ACC{1'b0}};
      result0 <= {ACC{1'b0}};
      result1 <= {ACC{1'b0}};
      ovf0    <= 1'b0;
      ovf1    <= 1'b0;
      ptr     <= {PW{1'b0}};
    end else if (mac2) begin
      acc0 <= s0[ACC-1:0];
      acc1 <= s1[ACC-1:0];
      if (s0[ACC] ^ s0[ACC-1]) ovf0 <= 1'b1;
      if (s1[ACC] ^ s1[ACC-1]) ovf1 <= 1'b1;
      ptr <= ptr + 1'b1;
    end else if (valid) begin
      case (cmd)
        C_CLEAR: begin
          acc0 <= {ACC{1'b0}};
          acc1 <= {ACC{1'b0}};
          ovf0 <= 1'b0;
          ovf1 <= 1'b0;
          ptr  <= {PW{1'b0}};
        end
        C_LOAD: ptr <= ptr + 1'b1;
        C_MAC: begin
          acc0 <= s0[ACC-1:0];
          if (s0[ACC] ^ s0[ACC-1]) ovf0 <= 1'b1;
          ptr <= ptr + 1'b1;
        end
        C_READ: begin
          result0 <= acc0;
          result1 <= acc1;
        end
        default: ;
      endcase
    end
  end

  // The buffer has no reset (it is always written before it is read)
  always @(posedge clk) begin
    if (valid && !mac2 && cmd == C_LOAD) x[ptr] <= din;
  end

  assign ptr_out = ptr;      // N = 32: PW = 5

endmodule

`default_nettype wire
