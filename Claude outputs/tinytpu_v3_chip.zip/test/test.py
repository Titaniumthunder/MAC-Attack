# SPDX-FileCopyrightText: © 2026 MAC Attack
# SPDX-License-Identifier: Apache-2.0
#
# Tiny-TPU v3 tests (two PEs, BURST mode). The test plays the host (the RP2040): it keeps the model,
# loads each layer's inputs once, then runs neurons two at a time with BURST (two weights per clock),
# reads both 22-bit sums, and does the rest of each layer itself. Must match exactly:
#   1. the professor's INT4 8-4-2 (golden_vectors.json): every sum = expected_acc
#   2. our modelV2 INT8 13-32-16-4 (modelV2/quant.json, host requantization between layers):
#      the last layer's sums = vectors_C.hex for all 64 rows
# Plus: handshake mode (PE 0 only), odd neuron counts, both PEs' products, separate overflow flags,
# burst lengths 1 and 32, bursts back to back, and clean switching between bursts and commands.

import json
import random
from pathlib import Path

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, FallingEdge, RisingEdge, Timer

NOP, CLEAR, LOAD_X, MAC, READ, BURST = 0, 1, 2, 3, 4, 5
HERE = Path(__file__).parent
ACC = 22


def u8(v):
    return v & 0xFF


class Host:
    def __init__(self, dut, mode):
        self.dut = dut
        self.mode = mode
        self.clocks = 0                      # clocks spent in streaming mode (for the speed comparison)

    def _uio(self, cmd=NOP, strobe=0, bsel=0, psel=0):
        return (cmd & 7) | (strobe << 3) | (self.mode << 4) | (bsel << 5) | (psel << 7)

    # ---- streaming: a list of clock slots (ui, uio), one per clock
    async def stream(self, slots):
        dut = self.dut
        for ui, uio in slots:
            await FallingEdge(dut.clk)
            dut.ui_in.value = ui
            dut.uio_in.value = uio
        await FallingEdge(dut.clk)
        dut.ui_in.value = 0
        dut.uio_in.value = self._uio()       # VALID = 0
        self.clocks += len(slots)

    def cmd_slot(self, cmd, data=0):
        return (u8(data), self._uio(cmd, 1))

    def burst_slots(self, w0s, w1s):
        n = len(w0s)
        return [self.cmd_slot(BURST, n)] + [(u8(a), u8(b)) for a, b in zip(w0s, w1s)]

    # ---- handshake (MODE 0): ACK is status bit 7, so BSEL = 3 while waiting
    async def handshake(self, ops):
        dut = self.dut
        for cmd, data in ops:
            dut.ui_in.value = u8(data)
            dut.uio_in.value = self._uio(cmd, 0, bsel=3)
            await ClockCycles(dut.clk, 1)
            dut.uio_in.value = self._uio(cmd, 1, bsel=3)
            await self._ack(1)
            dut.uio_in.value = self._uio(cmd, 0, bsel=3)
            await self._ack(0)

    async def _ack(self, level):
        for _ in range(50):
            await RisingEdge(self.dut.clk)
            await Timer(1, unit="ns")
            if int(self.dut.uo_out.value) >> 7 == level:
                return
        raise AssertionError(f"ACK never went {level}")

    # ---- reading
    async def _byte(self, bsel, psel=0):
        self.dut.uio_in.value = self._uio(NOP, 0, bsel, psel)
        await Timer(1, unit="ns")
        v = int(self.dut.uo_out.value)
        self.dut.uio_in.value = self._uio()
        return v

    async def read_sum(self, pe):
        b0, b1, b2 = await self._byte(0, pe), await self._byte(1, pe), await self._byte(2, pe)
        v = b0 | (b1 << 8) | ((b2 & 0x3F) << 16)
        return v - (1 << ACC) if v & (1 << (ACC - 1)) else v

    async def status(self):
        s = await self._byte(3)
        return {"ack": s >> 7, "ptr": (s >> 2) & 31, "ovf1": (s >> 1) & 1, "ovf0": s & 1}

    # ---- one layer: inputs once, then neurons two at a time (BURST) or one at a time (handshake)
    async def layer(self, x, cols):
        if self.mode == 1:
            await self.stream([self.cmd_slot(CLEAR)] + [self.cmd_slot(LOAD_X, v) for v in x])
            sums = []
            for j in range(0, len(cols), 2):
                w0 = cols[j]
                w1 = cols[j + 1] if j + 1 < len(cols) else [0] * len(w0)    # odd count: PE 1 idles on zeros
                await self.stream([self.cmd_slot(CLEAR)] + self.burst_slots(w0, w1) + [self.cmd_slot(READ)])
                st = await self.status()
                assert st["ovf0"] == 0 and st["ovf1"] == 0, "unexpected overflow"
                sums.append(await self.read_sum(0))
                if j + 1 < len(cols):
                    sums.append(await self.read_sum(1))
            return sums
        await self.handshake([(CLEAR, 0)] + [(LOAD_X, v) for v in x])
        sums = []
        for wj in cols:
            await self.handshake([(CLEAR, 0)] + [(MAC, w) for w in wj] + [(READ, 0)])
            sums.append(await self.read_sum(0))
        return sums


async def reset(dut):
    cocotb.start_soon(Clock(dut.clk, 20, unit="ns").start())   # 50 MHz
    dut.ena.value = 1
    dut.ui_in.value = 0
    dut.uio_in.value = 0
    dut.rst_n.value = 0
    await ClockCycles(dut.clk, 10)
    dut.rst_n.value = 1
    await ClockCycles(dut.clk, 5)


def requant(acc, bias, m0, sh, relu):
    """modelV2's integer step between layers (rtl/postproc.sv, mac_test.c requant)."""
    y = ((acc + bias) * m0 + (1 << (sh - 1))) >> sh
    return max(0 if relu else -128, min(127, y))


def professor_layers(vec):
    """Regroups one golden CLEAR/MAC/READ stream into layers: (inputs, weight columns, expected sums)."""
    neurons, cur = [], None
    for op in vec["commands"]:
        if op["op"] == "CLEAR":
            cur = {"layer": op["layer"], "a": [], "w": []}
        elif op["op"] == "MAC":
            cur["a"].append(op["a"])
            cur["w"].append(op["w"])
        else:
            cur["expected"] = op["expected_acc"]
            neurons.append(cur)
    out = []
    for layer in sorted({n["layer"] for n in neurons}):
        ns = [n for n in neurons if n["layer"] == layer]
        assert all(n["a"] == ns[0]["a"] for n in ns)
        out.append((ns[0]["a"], [n["w"] for n in ns], [n["expected"] for n in ns]))
    return out


async def check_professor(dut, host):
    vectors = json.loads((HERE / "golden_vectors.json").read_text())
    n = 0
    for i, vec in enumerate(vectors):
        for x, cols, expected in professor_layers(vec):
            got = await host.layer(x, cols)
            assert got == expected, f"vector {i}: {got} != {expected}"
            n += len(expected)
    return len(vectors), n


def load_modelv2():
    q = json.loads((HERE / "modelV2" / "quant.json").read_text())
    layers = q["layers"]
    if isinstance(layers, str):
        import ast
        layers = ast.literal_eval(layers)
    sizes = q["sizes"]
    xs = [int(l, 16) for l in (HERE / "modelV2" / "vectors_X.hex").read_text().split()]
    xs = [v - 256 if v > 127 else v for v in xs]
    X = [xs[r * sizes[0]:(r + 1) * sizes[0]] for r in range(len(xs) // sizes[0])]
    cs = [int(l, 16) for l in (HERE / "modelV2" / "vectors_C.hex").read_text().split()]
    cs = [v - (1 << 22) if v & (1 << 21) else v for v in cs]
    C = [cs[r * sizes[-1]:(r + 1) * sizes[-1]] for r in range(len(cs) // sizes[-1])]
    return layers, sizes, X, C


async def run_modelv2(host, layers, x):
    a = x
    for li, L in enumerate(layers):
        W = L["W"]                                           # K x N
        cols = [[W[k][j] for k in range(len(W))] for j in range(len(W[0]))]
        sums = await host.layer(a, cols)
        if li == len(layers) - 1:
            return sums
        a = [requant(s, L["bias"][j], L["m0"][j], L["shift"][j], L["relu"]) for j, s in enumerate(sums)]


@cocotb.test()
async def test_professor_int4_burst(dut):
    await reset(dut)
    nv, ns = await check_professor(dut, Host(dut, mode=1))
    dut._log.info(f"professor's INT4 model, 2 PEs in BURST: {nv} inferences, {ns} sums exact")


@cocotb.test()
async def test_professor_int4_handshake(dut):
    await reset(dut)
    nv, ns = await check_professor(dut, Host(dut, mode=0))
    dut._log.info(f"professor's INT4 model, handshake (PE 0): {nv} inferences, {ns} sums exact")


@cocotb.test()
async def test_modelv2_int8_burst(dut):
    await reset(dut)
    host = Host(dut, mode=1)
    layers, sizes, X, C = load_modelv2()
    for r, (x, c) in enumerate(zip(X, C)):
        got = await run_modelv2(host, layers, x)
        assert got == c, f"row {r}: {got} != {c}"
    per_row = host.clocks // len(X)
    # the same network one PE at a time (v2): per layer 1 + K loads, per neuron 1 + K + 1
    v2 = sum(1 + len(L["W"]) + len(L["W"][0]) * (len(L["W"]) + 2) for L in layers)
    dut._log.info(f"modelV2 {'-'.join(map(str, sizes))}, 2 PEs in BURST: {len(X)} rows exact, "
                  f"{per_row} clocks per inference (v2 one PE: {v2}, {v2 / per_row:.2f}x)")


@cocotb.test()
async def test_modelv2_int8_handshake(dut):
    await reset(dut)
    host = Host(dut, mode=0)
    layers, _, X, C = load_modelv2()
    for r in range(2):
        assert await run_modelv2(host, layers, X[r]) == C[r], f"row {r}"
    dut._log.info("modelV2 in handshake mode (PE 0): rows 0-1 exact")


@cocotb.test()
async def test_edge_cases(dut):
    await reset(dut)
    host = Host(dut, mode=1)
    rng = random.Random(9)

    # both PEs: one input, random weight pairs, burst length 1
    for _ in range(300):
        x, w0, w1 = (rng.randint(-128, 127) for _ in range(3))
        await host.stream([host.cmd_slot(CLEAR), host.cmd_slot(LOAD_X, x), host.cmd_slot(CLEAR)]
                          + host.burst_slots([w0], [w1]) + [host.cmd_slot(READ)])
        assert (await host.read_sum(0), await host.read_sum(1)) == (x * w0, x * w1), f"{x} {w0} {w1}"
    for x, w in ((-128, -128), (-128, 127), (127, 127), (0, -128)):
        await host.stream([host.cmd_slot(CLEAR), host.cmd_slot(LOAD_X, x), host.cmd_slot(CLEAR)]
                          + host.burst_slots([w], [w]) + [host.cmd_slot(READ)])
        assert (await host.read_sum(0), await host.read_sum(1)) == (x * w, x * w)
    dut._log.info("both PEs: 304 single products exact (incl. -128 * -128)")

    # full buffer, burst length 32, odd neuron count (3 neurons: the 2nd burst's PE 1 gets zeros)
    x = [rng.randint(-128, 127) for _ in range(32)]
    cols = [[rng.randint(-128, 127) for _ in range(32)] for _ in range(3)]
    assert await host.layer(x, cols) == [sum(a * b for a, b in zip(x, c)) for c in cols]
    assert (await host.status())["ptr"] == 0, "position wrapped to 0 after 32"
    dut._log.info("32 inputs x 3 neurons (odd count): exact")

    # bursts back to back without commands between them: the sums keep adding
    w0a, w1a = [rng.randint(-128, 127) for _ in range(5)], [rng.randint(-128, 127) for _ in range(5)]
    w0b, w1b = [rng.randint(-128, 127) for _ in range(5)], [rng.randint(-128, 127) for _ in range(5)]
    x = [rng.randint(-128, 127) for _ in range(10)]
    await host.stream([host.cmd_slot(CLEAR)] + [host.cmd_slot(LOAD_X, v) for v in x] + [host.cmd_slot(CLEAR)]
                      + host.burst_slots(w0a, w1a) + host.burst_slots(w0b, w1b) + [host.cmd_slot(READ)])
    assert await host.read_sum(0) == sum(a * b for a, b in zip(x, w0a + w0b))
    assert await host.read_sum(1) == sum(a * b for a, b in zip(x, w1a + w1b))
    dut._log.info("two bursts back to back: exact")

    # separate overflow flags: PE 0 overflows (128 x 16384), PE 1 does not
    await host.stream([host.cmd_slot(CLEAR)] + [host.cmd_slot(LOAD_X, -128)] * 32 + [host.cmd_slot(CLEAR)]
                      + host.burst_slots([-128] * 32, [1] * 32) * 4 + [host.cmd_slot(READ)])
    st = await host.status()
    assert st["ovf0"] == 1 and st["ovf1"] == 0, st
    assert await host.read_sum(1) == -128 * 128
    await host.stream([host.cmd_slot(CLEAR), host.cmd_slot(READ)])
    st = await host.status()
    assert st["ovf0"] == 0 and st["ovf1"] == 0 and await host.read_sum(0) == 0
    dut._log.info("overflow flags are per PE and cleared by CLEAR")

    # burst data that looks like commands must not run as commands, and the pins work after the burst:
    # every weight pair below is (READ-like, CLEAR-like) bytes; afterwards a normal READ must show the sums
    x = [3, -2, 7]
    await host.stream([host.cmd_slot(CLEAR)] + [host.cmd_slot(LOAD_X, v) for v in x] + [host.cmd_slot(CLEAR)]
                      + host.burst_slots([1, 2, 3], [0x1C, 0x19, 0x1D]) + [host.cmd_slot(READ)])
    w1 = [v - 256 if v > 127 else v for v in (0x1C, 0x19, 0x1D)]
    assert await host.read_sum(0) == 3 * 1 - 2 * 2 + 7 * 3
    assert await host.read_sum(1) == sum(a * b for a, b in zip(x, w1))
    dut._log.info("burst data never runs as commands; commands work right after")

    # BURST is ignored in handshake mode, and a strobe-like data bit before switching modes does not
    # fire a command (the last burst clock above had uio[3] = 1)
    hs = Host(dut, mode=0)
    await ClockCycles(dut.clk, 5)
    before = await hs.status()
    await hs.handshake([(BURST, 4)])
    after = await hs.status()
    assert after["ptr"] == before["ptr"], "BURST in handshake mode does nothing"
    await hs.handshake([(CLEAR, 0), (LOAD_X, 5), (CLEAR, 0), (MAC, -6), (READ, 0)])
    assert await hs.read_sum(0) == -30
    dut._log.info("handshake mode after bursts: clean; BURST ignored there")
