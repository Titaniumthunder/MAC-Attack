<!---

This file is used to generate your project datasheet. Please fill in the information below and delete any unused
sections.

You can also include images in this folder and reference them in the markdown. Each image must be less than
512 kb in size, and the combined size of all images must be less than 1 MB.
-->

## How it works

Tiny-TPU v3 is a small neural-network accelerator by team MAC Attack (Alex Salamati, James Manikyan,
Marco Flores), for a motor-vibration fault detector: a 1x2 array of processing elements.

Each PE multiplies signed 8-bit numbers (INT8) and adds the products into an exact 22-bit sum. Both PEs share a
32-byte **input buffer**: the host loads a layer's inputs once, then a **BURST** brings in two weights per clock
(one on `ui_in`, one on `uio_in`), so the two PEs compute two neurons of the layer at the same time. The host
(the RP2040 on the demo board) keeps the model, runs it layer by layer, and does each layer's bias, rescaling and
ReLU. Any model whose layers have at most 32 inputs runs without changing the chip; INT4 models work too.

Commands: `CLEAR` (both sums = 0, buffer position 0), `LOAD_X` (store the next input), `MAC` (one weight, PE 0
only), `READ` (copy both sums to the output registers), `BURST n` (the next n clocks are weight pairs), `NOP`.
A sum that leaves the 22-bit range sets that PE's overflow flag until the next `CLEAR`.

## How to test

Normal pins: DATA on `ui_in`; CMD on `uio_in[2:0]` (0 NOP, 1 CLEAR, 2 LOAD_X, 3 MAC, 4 READ, 5 BURST);
STROBE/VALID on `uio_in[3]`; MODE on `uio_in[4]`; BSEL on `uio_in[6:5]`; PSEL (which PE) on `uio_in[7]`.
`uo_out` shows the selected PE's sum bits 7:0 (BSEL 0), 15:8 (BSEL 1), 21:16 sign-extended (BSEL 2), or the
status byte {ACK, buffer position[4:0], OVF1, OVF0} (BSEL 3). All `uio` pins are inputs.

MODE 1 (streaming): every rising clock with VALID = 1 runs CMD on DATA. `BURST n` (DATA = n) turns the next n
clocks into weight pairs: `ui_in` = PE 0's weight, `uio_in` = PE 1's weight. Inputs must be synchronous to the
clock. MODE 0 (handshake, any host speed, PE 0 only): set DATA and CMD, raise STROBE, wait for ACK = 1 (status bit
7, BSEL = 3), lower STROBE, wait for ACK = 0.

Two neurons with inputs 3, -2 and weights (2, 4) and (1, -5): `CLEAR`, `LOAD_X 3`, `LOAD_X -2`, `CLEAR`,
`BURST 2`, then the pairs (2, 1) and (4, -5), then `READ`: PE 0 gives 6 - 8 = -2, PE 1 gives 3 + 10 = 13.

## External hardware

None beyond the Tiny Tapeout demo board: its RP2040 acts as the host.
